const arr=[1,4,5,6,7,8,9];
let result=arr.filter(function(b){

    return b%2==0;
})
console.log(result);

const Arr=[2,4,6,7,8,9];
let ans=Arr.map((b)=>{
    return b%2==0;


})
console.log(ans);

const vp=[1,2,3,4,5,6,7];
//vp.map((b)=>{
let ans1=vp.map((b)=>{

   // console.log(b*b);
   return b*b;
})
console.log(ans1);