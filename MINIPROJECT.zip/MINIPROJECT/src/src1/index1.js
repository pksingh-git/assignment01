console.log("ok");
var pk;
console.log(pk);
const jk=0;
console.log(jk);
let pl=9;
console.log(pl);
console.table({name:"prince",roll:23,status:"Employeed"});
console.log(typeof pl);
let myArray=[1,2,3,4,5,6];
console.log(myArray+" "+typeof myArray);
// TYPE CONVERSION 
let  myVar=12;
console.log(myVar,typeof myVar);
myVar=String(myVar);
console.log(myVar,typeof myVar);
let myFoot=true;
console.log(myFoot,typeof myFoot);
myFoot=String(myFoot)
console.log(typeof myFoot);
let date= new Date();
console.log(date,typeof date);
date=String(date);
console.log(typeof date);


let flotA=34.456;

console.log(flotA);

flotA=parseInt(flotA);

console.log(flotA);

let flotB=parseFloat(65.0987);

console.log(flotB);

console.log(flotA.toFixed(19));


// STRING METHOD & PROPERTIES 

let result="prince is  on the way"

console.log(result[2]);
console.log(result.charAt(2)); 
console.log(result.indexOf("i")); // return first occurance
console.log(result.lastIndexOf("i")); //. retrun  last one 
console.log(result.endsWith("y"));
console.log(result.replace("on","ON"));
console.log(result.slice(0,6));