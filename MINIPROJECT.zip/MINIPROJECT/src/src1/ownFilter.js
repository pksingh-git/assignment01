Array.prototype.myFilter=function(cb)
{
//console.log(cb);
console.log(this);
    const newFilterArray=[];

    for(let index=0;index<this.length;index++){
        if(cb(this[index],index,this))
        newFilterArray.push(this[index]);

    }
    return newFilterArray;

}

const ab=[1,2,3,4,5,6,7];
let result=ab.myFilter((b)=>{
    return b>5;
})
console.log(result);