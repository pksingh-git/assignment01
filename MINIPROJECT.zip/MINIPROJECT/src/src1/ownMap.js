Array.prototype.myMap= function(callback){
  console.log(callback);
const newArray=[];
//console.log(this);
for(let index=0;index<this.length;index++)  //this represent array itself or refers to the array on which myMap is done
{
    newArray.push(callback(this[index],index,this));
}
 return newArray;
}

const nw=[1,2,3,4,5,6];
//let ans=nw.myMap(function(val,index,array){
    let ans=nw.map((b)=>{



    return b*0;
})
console.log(ans);
