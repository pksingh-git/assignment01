// let name="prince";
// let roll=13;

// let myData = `Hello My Name is ${name} and 
// My Roll "Number" is ${roll}.

// <h1> Thats it</h1>
// `;
//document.body.innerHTML=myData;
 function add(x,y){

return x+y;



}
let result=add(45,9);
console.log(result);
let ans=(a,b)=>{
  return a*b;
}
let pos=ans(4,7);
console.log(pos);

var myObj={
name:"prince",
email:"princevns024@gmail.com",
status:"isActive",
getInfo: function(){
    return `The name is ${myObj.name} and
    email is ${myObj.email} and final status is ${myObj.status}
    `;

}
}
let ans1=myObj.getInfo();
console.log(ans1);