import { bookManager } from "./bookManager.js";
let objManager = new bookManager();
objManager.displayBookList();
