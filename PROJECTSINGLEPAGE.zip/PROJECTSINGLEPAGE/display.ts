import{bookManager} from "./bookManager.js"

let objManager:bookManager=new bookManager();
objManager.displayBookList();
